import { Routes } from '@angular/router';

import { RtlComponent } from '../../pages/rtl/rtl.component';


export const AuthLayoutRoutes: Routes = [
    { path: 'rtl',          component: RtlComponent },
];
